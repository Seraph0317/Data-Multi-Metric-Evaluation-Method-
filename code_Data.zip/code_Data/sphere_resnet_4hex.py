# Copyright (c) OpenMMLab. All rights reserved.
import os
import pickle
import warnings
from typing import Dict, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn as nn
import torch.utils.checkpoint as cp
from mmcv.cnn import (build_activation_layer, build_norm_layer,
                      build_padding_layer)
from mmcv.cnn.bricks import DropPath
from mmengine.model import BaseModule
from mmengine.model.weight_init import constant_init, kaiming_init
from mmengine.utils.dl_utils.parrots_wrapper import _BatchNorm, _InstanceNorm
from torch.nn import functional as F

from mmcls.registry import MODELS
from ..utils import make_adjacency_table, make_deconv_table, make_pooling_table
from .base_backbone import BaseBackbone

eps = 1.0e-5
class  sphere_conv_Sequential(nn.Sequential):
    def forward(self, input, conv_table,pooltable=None):
        for module in self:
            # 重载的Sequential方法
            input = module(input,conv_table,pooltable)
        return input
class  sphereDownSample(nn.Module):
    def __init__(self,avg,listmoudle ):
        super().__init__()
        self.avg =avg
        self.mlist = nn.ModuleList()
        for m in listmoudle:

         self.mlist.append(m)
    @property
    def getmlist(self):
        return self.mlist
    def forward(self, input, pooltable=None):
        for i,module in enumerate(self.mlist) :
            if isinstance(module, _BatchNorm):
                input = module(input )
            else: 
                input = module(input,pooltable)
        return input
class ConvModule(nn.Module):
    """A conv block that bundles conv/norm/activation layers.

    This block simplifies the usage of convolution layers, which are commonly
    used with a norm layer (e.g., BatchNorm) and activation layer (e.g., ReLU).
    It is based upon three build methods: `build_conv_layer()`,
    `build_norm_layer()` and `build_activation_layer()`.

    Besides, we add some additional features in this module.
    1. Automatically set `bias` of the conv layer.
    2. Spectral norm is supported.
    3. More padding modes are supported. Before PyTorch 1.5, nn.Conv2d only
    supports zero and circular padding, and we add "reflect" padding mode.

    Args:
        in_channels (int): Number of channels in the input feature map.
            Same as that in ``nn._ConvNd``.
        out_channels (int): Number of channels produced by the convolution.
            Same as that in ``nn._ConvNd``.
        kernel_size (int | tuple[int]): Size of the convolving kernel.
            Same as that in ``nn._ConvNd``.
        stride (int | tuple[int]): Stride of the convolution.
            Same as that in ``nn._ConvNd``.
        padding (int | tuple[int]): Zero-padding added to both sides of
            the input. Same as that in ``nn._ConvNd``.
        dilation (int | tuple[int]): Spacing between kernel elements.
            Same as that in ``nn._ConvNd``.
        groups (int): Number of blocked connections from input channels to
            output channels. Same as that in ``nn._ConvNd``.
        bias (bool | str): If specified as `auto`, it will be decided by the
            norm_cfg. Bias will be set as True if `norm_cfg` is None, otherwise
            False. Default: "auto".
        conv_cfg (dict): Config dict for convolution layer. Default: None,
            which means using conv2d.
        norm_cfg (dict): Config dict for normalization layer. Default: None.
        act_cfg (dict): Config dict for activation layer.
            Default: dict(type='ReLU').
        inplace (bool): Whether to use inplace mode for activation.
            Default: True.
        with_spectral_norm (bool): Whether use spectral norm in conv module.
            Default: False.
        padding_mode (str): If the `padding_mode` has not been supported by
            current `Conv2d` in PyTorch, we will use our own padding layer
            instead. Currently, we support ['zeros', 'circular'] with official
            implementation and ['reflect'] with our own implementation.
            Default: 'zeros'.
        order (tuple[str]): The order of conv/norm/activation layers. It is a
            sequence of "conv", "norm" and "act". Common examples are
            ("conv", "norm", "act") and ("act", "conv", "norm").
            Default: ('conv', 'norm', 'act').
    """

    _abbr_ = 'conv_block'

    def __init__(self,kconv,
                 in_channels: int,
                 out_channels: int,
                 k_pool,
                 stride: Union[int, Tuple[int, int]] = (1,1),
                 bias: Union[bool, str] = 'auto',
                 norm_cfg: Optional[Dict] = None,
                 act_cfg: Optional[Dict] = dict(type='ReLU'),
                 inplace: bool = True,
                 with_spectral_norm: bool = False,
                 order: tuple = ('conv', 'norm', 'act'),
                 nousestride=False):
        super().__init__()
        assert norm_cfg is None or isinstance(norm_cfg, dict)
        assert act_cfg is None or isinstance(act_cfg, dict)
        self.norm_cfg = norm_cfg
        self.act_cfg = act_cfg
        self.inplace = inplace
        self.with_spectral_norm = with_spectral_norm
        self.order = order
        assert isinstance(self.order, tuple) and len(self.order) == 3
        assert set(order) == {'conv', 'norm', 'act'}

        self.with_norm = norm_cfg is not None
        self.with_activation = act_cfg is not None
        # if the conv layer is before a norm layer, bias is unnecessary.
        if bias == 'auto':
            bias = not self.with_norm
        self.with_bias = bias
 
        # build convolution layer 是否下采样 由stride操控
        self.conv = create_conv(
            kconv,
            in_channels,
            out_channels,
            k_pool=k_pool,
            stride=stride,
            bias=bias,
            nousestride=nousestride)
        # export the attributes of self.conv to a higher level for convenience create_conv类没有呀这些属性
        # self.in_channels = self.conv.in_channels
        # self.out_channels = self.conv.out_channels
        # self.kernel_size = self.conv.kernel_size
        # self.stride = self.conv.stride
        # self.padding = padding
        # self.dilation = self.conv.dilation
        # self.transposed = self.conv.transposed
        # self.output_padding = self.conv.output_padding
        # self.groups = self.conv.groups

        if self.with_spectral_norm:
            self.conv = nn.utils.spectral_norm(self.conv)

        # build normalization layers
        if self.with_norm:
            # norm layer is after conv layer
            if order.index('norm') > order.index('conv'):
                norm_channels = out_channels
            else:
                norm_channels = in_channels
            self.norm_name, norm = build_norm_layer(
                norm_cfg, norm_channels)  # type: ignore
            self.add_module(self.norm_name, norm)
            if self.with_bias:
                if isinstance(norm, (_BatchNorm, _InstanceNorm)):
                    warnings.warn(
                        'Unnecessary conv bias before batch/instance norm')
        else:
            self.norm_name = None  # type: ignore

        # build activation layer
        if self.with_activation:
            act_cfg_ = act_cfg.copy()  # type: ignore
            self.activate = build_activation_layer(act_cfg_)
        # Use msra init by default
        self.init_weights()

    @property
    def norm(self):
        if self.norm_name:
            return getattr(self, self.norm_name)
        else:
            return None

    def init_weights(self):
        # 1. It is mainly for customized conv layers with their own
        #    initialization manners by calling their own ``init_weights()``,
        #    and we do not want ConvModule to override the initialization.
        # 2. For customized conv layers without their own initialization
        #    manners (that is, they don't have their own ``init_weights()``)
        #    and PyTorch's conv layers, they will be initialized by
        #    this method with default ``kaiming_init``.
        # Note: For PyTorch's conv layers, they will be overwritten by our
        #    initialization implementation using default ``kaiming_init``.
        if not hasattr(self.conv, 'init_weights'):
            if self.with_activation and self.act_cfg['type'] == 'LeakyReLU':
                nonlinearity = 'leaky_relu'
                a = self.act_cfg.get('negative_slope', 0.01)
            else:
                nonlinearity = 'relu'
                a = 0
            kaiming_init(self.conv, a=a, nonlinearity=nonlinearity)
        if self.with_norm:
            constant_init(self.norm, 1, bias=0)

    def forward(self,
                x: torch.Tensor,
                conv_table,
                pooltable,
                activate: bool = True,
                norm: bool = True) -> torch.Tensor:
        for layer in self.order:
            if layer == 'conv':
                x = self.conv(x,conv_table,pooltable)
            elif layer == 'norm' and norm and self.with_norm:
                x = self.norm(x)
            elif layer == 'act' and activate and self.with_activation:
                x = self.activate(x)
        return x

class sconv1x1(nn.Module):
    """ 
  
        in_dim (_type_): C0
        out_dim (_type_): C1
        stride (int, optional):  
    """

    def __init__(self, in_dim, out_dim, pool_ks, stride=1,  bias=True ,nousestride=False):
        super().__init__()
        self.nousestride =nousestride
        self.stride =stride
        if stride !=1 and nousestride : 
            self.maxpool =smaxpool( kernel_size=pool_ks, return_indices=False)
            self.conv = torch.nn.Conv1d(in_channels=in_dim,out_channels= out_dim,kernel_size=1,stride=1,padding=0,bias=bias)
        else:
            self.conv = torch.nn.Conv1d(in_channels=in_dim,out_channels= out_dim,kernel_size=1,stride=stride,padding=0,bias=bias)

    def forward(self, input,pool_table=None):
        """Forward function.
        input (_type_): dim= N,C0,L0
        """

        x = self.conv(input)
        if self.stride!=1 and self.nousestride : 
            x =self.maxpool(x,pool_table)
        return x

class sconv(nn.Module):
    def __init__(self, in_dim, out_dim, kernel_size,pool_ks, stride=(1,1) , bias=True ,nousestride=False):
        super().__init__()
        self.nousestride =nousestride
        self.stride =stride
        
        if stride[0]!=1 and nousestride :#如果stride 不为1 切不打算使用stride 那么使用maxpool
            self.conv = torch.nn.Conv2d(in_channels=in_dim,out_channels= out_dim,kernel_size=kernel_size,stride=(1,1),padding=0,bias=bias)
            self.maxpool = smaxpool( kernel_size=pool_ks,   return_indices=False)
        else:
            self.conv = torch.nn.Conv2d(in_channels=in_dim,out_channels= out_dim,kernel_size=kernel_size,stride=stride,padding=0,bias=bias)

    def forward(self, input,conv_table,pool_table=None):
        """Forward function.
        input (_type_): dim= N,C0,L0
        conv_table:dim= L0,K
        """
        # # N,C0,L0 =>N,C0,L0,K
        conv_data = input[:,:,conv_table] 
        x = self.conv(conv_data).squeeze(-1)
        if self.stride[0]!=1 and self.nousestride :# 
            x =self.maxpool(x,pool_table)
        return x

class smaxpool(nn.Module):

    def __init__(self, kernel_size , return_indices=False ):
        super().__init__()
        self.pool = torch.nn.MaxPool2d( kernel_size=kernel_size,stride=1,padding=0 ,return_indices=return_indices)
    
    def forward(self, input,pool_table):
        # N,C0,L0 =>N,C0,l1,4
        pool_data = input[:,:,pool_table] 
        #N,C0,l1,K =>N,C0,l1,1=>N,C0,l1
        x = self.pool(pool_data).squeeze(-1)
        return x
class savgpool(nn.Module): 

    def __init__(self, k_pool  ):
        super().__init__()
        self.k_pool =k_pool
        if   k_pool ==4 : ##菱形和三角形
            self.pool = torch.nn.AvgPool2d( kernel_size=(1,k_pool),stride=1,padding=0  )
        elif k_pool == 7 :##四孔六边形
            data = np.array([1.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5])/4.0
            weight0 =  torch.tensor(data,requires_grad=False,dtype=torch.float32) 
            self.register_buffer('weight', weight0)
        else:
            raise f"error savgpool k_pool {k_pool}"
    def forward(self, input,pool_table):
        # N,C0,L0 =>N,C0,l1,4
        pool_data = input[:,:,pool_table]
        if self.k_pool !=4:
            pool_shape = pool_data.shape
            weight = self.weight.expand(pool_shape[1], pool_shape[1], 1, self.weight.shape[0])
            out = F.conv2d(pool_data, weight, None, stride=1, padding=0).squeeze(-1)
        else:
            out  = self.pool(pool_data).squeeze(-1)
        return out


class sde_conv(nn.Module):
    def __init__(self, in_dim, out_dim, kernel_size=4, stride=4,  bias=True ):
        """_summary_

        Args:
            in_dim (_type_): _description_
            out_dim (_type_): _description_
            kernel_size (tuple, optional): 对于四分格网使用默认的kernel 和stirde即可. Defaults to 4.
            stride (int, optional): _description_. Defaults to 4.
            bias (bool, optional): _description_. Defaults to True.
        """        
        super().__init__()
        self.de_conv =   nn.ConvTranspose1d(in_channels= in_dim,out_channels=out_dim,kernel_size=kernel_size,stride=stride,padding=0,bias=False) 
    def forward(self, input ,sort_array):
        x = self.de_conv(input) 
        x = x[:,:,sort_array]
        return x


def create_conv(k_conv,in_dim,out_dim,  k_pool,stride=(1,1),  bias=True,nousestride=False):
    kernel_size=(1, k_conv)
    if k_pool and nousestride:  
        pool_ks =(1,k_pool)
    else:
        pool_ks=None
    return sconv(in_dim=in_dim,out_dim= out_dim,kernel_size=kernel_size, pool_ks=pool_ks,
    stride=stride,bias=bias,nousestride=nousestride)

def create_maxpool(k_pool, return_indices=False):
    kernel_size=(1, k_pool)
    return smaxpool( kernel_size=kernel_size,   return_indices=return_indices)

def create_avgpool(k_pool ):
    return savgpool( k_pool= k_pool )
def create_deconv(k_pool, in_dim,out_dim, bias=True): 
    kernel_size= k_pool
    stride =  k_pool
    return sde_conv(in_dim=in_dim,out_dim= out_dim,kernel_size=kernel_size,  
    stride=stride,bias=bias)

class BasicBlock(BaseModule):
    def __init__(self,
                 in_channels,
                 out_channels,
                 k_conv  ,
                 k_pool,
                 expansion=1,
                 stride=(1,1),
                 dilation=1,
                 downsample=None,
                 style='pytorch',
                 with_cp=False,
                 nousestride=False,
                 norm_cfg=dict(type='BN1d'),#只能使用1维的norm
                 drop_path_rate=0.0,
                 act_cfg=dict(type='SiLU', inplace=False),##等价Swish
                 init_cfg=None):
        super(BasicBlock, self).__init__(init_cfg=init_cfg)
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.expansion = expansion
        assert self.expansion == 1
        assert out_channels % expansion == 0
        self.mid_channels = out_channels // expansion
        self.stride = stride
        self.dilation = dilation
        self.style = style
        self.with_cp = with_cp
        self.norm_cfg = norm_cfg

        self.norm1_name, norm1 = build_norm_layer(
            norm_cfg, self.mid_channels, postfix=1)
        self.norm2_name, norm2 = build_norm_layer(
            norm_cfg, out_channels, postfix=2)
 
        self.conv1 = create_conv(
            k_conv=k_conv,
            in_dim =in_channels,
            out_dim = self.mid_channels,
            k_pool=k_pool,
            stride=stride,
            bias=False,
            nousestride=nousestride)
        self.add_module(self.norm1_name, norm1)
        self.conv2 = create_conv(
            k_conv =k_conv,
            in_dim =self.mid_channels,
            out_dim =out_channels,
            k_pool=k_pool,
            bias=False,
            nousestride=nousestride)
        self.add_module(self.norm2_name, norm2)

        self.act = build_activation_layer(act_cfg)
        self.downsample = downsample ##要替换为spool 是x分支的池化方式 
        self.drop_path = DropPath(drop_prob=drop_path_rate
                                  ) if drop_path_rate > eps else nn.Identity()

    @property
    def norm1(self):
        return getattr(self, self.norm1_name)

    @property
    def norm2(self):
        return getattr(self, self.norm2_name)
    
    def forward(self, x,conv_tables,pool_table=None):
 
        def _inner_forward(x,conv_tables,pool_table=None):
            if   self.downsample is not None:  
                identity = x

                out = self.conv1(x,conv_tables[0],pool_table) 
                out = self.norm1(out)
                out = self.act(out)

                out = self.conv2(out,conv_tables[1])
                out = self.norm2(out)

                identity = self.downsample(x,pool_table)
            else: 
                identity = x
                out = self.conv1(x,conv_tables[0])
                out = self.norm1(out)
                out = self.act(out)

                out = self.conv2(out,conv_tables[0])
                out = self.norm2(out)

            out = self.drop_path(out)

            out  = out +identity
 
            return out

        if self.with_cp and x.requires_grad:
            out = cp.checkpoint(_inner_forward, x,conv_tables, pool_table)
        else:
            out = _inner_forward(x,conv_tables,pool_table=pool_table)

        out = self.act(out)

        return out
    def forwardxxx(self, x,conv_tables,pool_table=None):
        def _inner_forward(x,conv_tables,pool_table=None):
            if   self.downsample is not None:  
                identity = x

                out = self.conv1(x,conv_tables[0])
                out = self.norm1(out)
                out = self.act(out)

                out = self.conv2(out,conv_tables[1])
                out = self.norm2(out)

                identity = self.downsample(x,pool_table)
            else:
                identity = x
                out = self.conv1(x,conv_tables[0])
                out = self.norm1(out)
                out = self.act(out)

                out = self.conv2(out,conv_tables[0])
                out = self.norm2(out)

            out = self.drop_path(out)

            out  = out+ identity

            return out

        if self.with_cp and x.requires_grad:
            out = cp.checkpoint(_inner_forward, x,conv_tables,pool_table=pool_table)
        else:
            out = _inner_forward(x,conv_tables,pool_table=pool_table)

        out = self.act(out)

        return out


class Bottleneck(BaseModule):
    """Bottleneck block for ResNet.

    Args:
        in_channels (int): Input channels of this block.
        out_channels (int): Output channels of this block.
        expansion (int): The ratio of ``out_channels/mid_channels`` where
            ``mid_channels`` is the input/output channels of conv2. Default: 4.
        stride (int): stride of the block. Default: 1
        dilation (int): dilation of convolution. Default: 1
        downsample (nn.Module, optional): downsample operation on identity
            branch. Default: None.
        style (str): ``"pytorch"`` or ``"caffe"``. If set to "pytorch", the
            stride-two layer is the 3x3 conv layer, otherwise the stride-two
            layer is the first 1x1 conv layer. Default: "pytorch".
        with_cp (bool): Use checkpoint or not. Using checkpoint will save some
            memory while slowing down the training speed.
        conv_cfg (dict, optional): dictionary to construct and config conv
            layer. Default: None
        norm_cfg (dict): dictionary to construct and config norm layer.
            Default: dict(type='BN')
    """

    def __init__(self,
                 in_channels,
                 out_channels,
                 k_conv,
                 k_pool ,
                 expansion=4,
                 stride=1,
                 dilation=1,
                 downsample=None,
                 style='pytorch',
                 with_cp=False,
                 nousestride=False,
                 norm_cfg=dict(type='BN1d'),
                 act_cfg=dict(type='SiLU', inplace=False),
                 drop_path_rate=0.0,
                 init_cfg=None):
        super(Bottleneck, self).__init__(init_cfg=init_cfg)
        assert style in ['pytorch', 'caffe']

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.expansion = expansion
        assert out_channels % expansion == 0
        self.mid_channels = out_channels // expansion
        self.stride = stride
        self.dilation = dilation
        self.style = style
        self.with_cp = with_cp
        self.norm_cfg = norm_cfg
        if self.style == 'pytorch':
            self.conv1_stride = (1,1)
            self.conv2_stride = stride
        else:
            self.conv1_stride = stride
            self.conv2_stride = (1,1)

        self.norm1_name, norm1 = build_norm_layer(
            norm_cfg, self.mid_channels, postfix=1)
        self.norm2_name, norm2 = build_norm_layer(
            norm_cfg, self.mid_channels, postfix=2)
        self.norm3_name, norm3 = build_norm_layer(
            norm_cfg, out_channels, postfix=3)

        self.conv1 = sconv1x1(
            in_dim= in_channels,
            out_dim= self.mid_channels,
            pool_ks=(1, k_pool), 
            stride=self.conv1_stride[0], 
            bias=False,
            nousestride=nousestride)
        self.add_module(self.norm1_name, norm1)
        self.conv2 = create_conv(
            k_conv=k_conv,
            in_dim= self.mid_channels,
            out_dim = self.mid_channels,
            stride=self.conv2_stride,
            k_pool= k_pool,
            bias=False,
            nousestride=nousestride)

        self.add_module(self.norm2_name, norm2)
        self.conv3 = sconv1x1(
            in_dim =self.mid_channels,
            out_dim = out_channels,
            pool_ks=(1, k_pool), 
            bias=False,
            nousestride=nousestride)
        self.add_module(self.norm3_name, norm3)

        self.act = build_activation_layer(act_cfg)
        self.downsample = downsample
        self.drop_path = DropPath(drop_prob=drop_path_rate
                                  ) if drop_path_rate > eps else nn.Identity()

    @property
    def norm1(self):
        return getattr(self, self.norm1_name)

    @property
    def norm2(self):
        return getattr(self, self.norm2_name)

    @property
    def norm3(self):
        return getattr(self, self.norm3_name)

    def forward(self, x,conv_tables,pool_table=None):

        def _inner_forward(x, conv_tables,pool_table=None):
            if self.stride[0]!=1: 
                if self.style != 'pytorch':   
  
                    identity = x
                    out = self.conv1(x ,pool_table)  
                    out = self.norm1(out)
                    out = self.act(out)
                    out = self.conv2(out,conv_tables[1] )
                    out = self.norm2(out)
                    out = self.act(out)
                    out = self.conv3(out)
                    out = self.norm3(out)
                else :
 
                    identity = x
                    out = self.conv1(x )
                    out = self.norm1(out)
                    out = self.act(out)

                    out = self.conv2(out,conv_tables[0],pool_table )
                    out = self.norm2(out)
                    out = self.act(out)

                    out = self.conv3(out)
                    out = self.norm3(out)
            else: 
                    identity = x
                    out = self.conv1(x )
                    out = self.norm1(out)
                    out = self.act(out)

                    out = self.conv2(out,conv_tables[0] )
                    out = self.norm2(out)
                    out = self.act(out)

                    out = self.conv3(out)
                    out = self.norm3(out)
            out = self.drop_path(out)
            if self.downsample is not None: 
                identity = self.downsample(x, pool_table)
            out += identity
 
            return out

        if self.with_cp and x.requires_grad:
            out = cp.checkpoint(_inner_forward, x,conv_tables, pool_table)
        else:
            out = _inner_forward(x,conv_tables,pool_table=pool_table)

        out = self.act(out)

        return out


def get_expansion(block, expansion=None):
    """Get the expansion of a residual block.

    The block expansion will be obtained by the following order:

    1. If ``expansion`` is given, just return it.
    2. If ``block`` has the attribute ``expansion``, then return
       ``block.expansion``.
    3. Return the default value according the the block type:
       1 for ``BasicBlock`` and 4 for ``Bottleneck``.

    Args:
        block (class): The block class.
        expansion (int | None): The given expansion ratio.

    Returns:
        int: The expansion of the block.
    """
    if isinstance(expansion, int):
        assert expansion > 0
    elif expansion is None:
        if hasattr(block, 'expansion'):
            expansion = block.expansion
        elif issubclass(block, BasicBlock):
            expansion = 1
        elif issubclass(block, Bottleneck):
            expansion = 4
        else:
            raise TypeError(f'expansion is not specified for {block.__name__}')
    else:
        raise TypeError('expansion must be an integer or None')

    return expansion


class ResLayer(nn.ModuleList):
    """ResLayer to build ResNet style backbone.

    Args:
        block (nn.Module): Residual block used to build ResLayer. BasicBlock/Bottleneck.
        num_blocks (int): Number of blocks.
        in_channels (int): Input channels of this block.
        out_channels (int): Output channels of this block.
        expansion (int, optional): The expansion for BasicBlock/Bottleneck.
            If not specified, it will firstly be obtained via
            ``block.expansion``. If the block has no attribute "expansion",
            the following default values will be used: 1 for BasicBlock and
            4 for Bottleneck. Default: None.
        stride (int): stride of the first block. Default: 1.
        avg_down (bool): Use AvgPool instead of stride conv when
            downsampling in the bottleneck. Default: False
        conv_cfg (dict, optional): dictionary to construct and config conv
            layer. Default: None
        norm_cfg (dict): dictionary to construct and config norm layer.
            Default: dict(type='BN')
    """

    def __init__(self,
                 block,
                 num_blocks,
                 in_channels,
                 out_channels,
                 kconv,    
                 kpool,
                 nousestride ,
                 expansion=None,
                 stride=1,
                 avg_down=False,
                 norm_cfg=dict(type='BN1d'),
                 act_cfg=dict(type='SiLU', inplace=False),
                 **kwargs):
        self.block = block
        self.expansion = get_expansion(block, expansion)
        self.useconvtable1=False
        downsample = None
        self.stride = stride 
        ifavg=False 

        if stride[0] != 1 or in_channels != out_channels:
            downsample = []
            conv_stride = stride
            if avg_down and stride[0] != 1:
                conv_stride = (1,1)  
                downsample.append(
                    create_avgpool(k_pool=kpool))
                ifavg=True
            downsample.extend([
                sconv1x1(
                    in_channels,
                    out_channels,
                    pool_ks =(1,kpool),
                    stride=conv_stride[0], 
                    bias=False,
                    nousestride=nousestride),
                build_norm_layer(norm_cfg, out_channels)[1]
            ])
            downsample = sphereDownSample(avg=ifavg,listmoudle= downsample)
 
        layers = []
        layers.append(
            block(
                in_channels=in_channels,
                out_channels=out_channels,
                k_conv = kconv,
                k_pool =kpool,
                expansion=self.expansion,
                stride=stride,
                downsample=downsample,
                nousestride=nousestride,
                norm_cfg=norm_cfg,
                act_cfg =act_cfg,
                **kwargs))
        in_channels = out_channels  
        for i in range(1, num_blocks):
            layers.append(
                block(
                    in_channels=in_channels,
                    out_channels=out_channels,
                    k_conv=kconv,
                    k_pool =kpool,
                    expansion=self.expansion,
                    stride=(1,1),
                    nousestride=False ,##使用stride
                    norm_cfg=norm_cfg,
                    act_cfg =act_cfg,
                    **kwargs))
        super(ResLayer, self).__init__(layers)
    def forward(self, x,conv_tables,pooltable=None):
 
        for i,m in enumerate(self) :
 
            if i==0 and m.stride[0]!=1:
                x = m(x,conv_tables,pooltable)
                self.useconvtable1 =True
            elif not self.useconvtable1: 
                x = m(x,(conv_tables[0],None) ,None )
            else : 
                x = m(x,(conv_tables[1],None ),None )


        return x     


 
@MODELS.register_module()
class sphereResNetHex_1(BaseBackbone):
    """ResNet backbone.
 
    Please refer to the `paper <https://arxiv.org/abs/1512.03385>`__ for
    details.

    Args:
        depth (int): Network depth, from {18, 34, 50, 101, 152}.
        in_channels (int): Number of input image channels. Default: 3.
        stem_channels (int): Output channels of the stem layer. Default: 64.
        base_channels (int): Middle channels of the first stage. Default: 64.
        num_stages (int): Stages of the network. Default: 4.
        strides (Sequence[int]): Strides of the first block of each stage.
            Default: ``(1, 2, 2, 2)``.
        dilations (Sequence[int]): Dilation of each stage.
            Default: ``(1, 1, 1, 1)``.
        out_indices (Sequence[int]): Output from which stages.
            Default: ``(3, )``.
        style (str): `pytorch` or `caffe`. If set to "pytorch", the stride-two
            layer is the 3x3 conv layer, otherwise the stride-two layer is
            the first 1x1 conv layer.
        avg_down (bool): Use AvgPool instead of stride conv when
            downsampling in the bottleneck. Default: False.
        frozen_stages (int): Stages to be frozen (stop grad and set eval mode).
            -1 means not freezing any parameters. Default: -1.
        conv_cfg (dict | None): The config dict for conv layers. Default: None.
        norm_cfg (dict): The config dict for norm layers.
        norm_eval (bool): Whether to set norm layers to eval mode, namely,
            freeze running stats (mean and var). Note: Effect on Batch Norm
            and its variants only. Default: False.
        with_cp (bool): Use checkpoint or not. Using checkpoint will save some
            memory while slowing down the training speed. Default: False.
        zero_init_residual (bool): Whether to use zero init for last norm layer
            in resblocks to let them behave as identity. Default: True.

    Example:
        >>> from mmcls.models import ResNet
        >>> import torch
        >>> self = ResNet(depth=18)
        >>> self.eval()
        >>> inputs = torch.rand(1, 3, 32, 32)
        >>> level_outputs = self.forward(inputs)
        >>> for level_out in level_outputs:
        ...     print(tuple(level_out.shape))
        (1, 64, 8, 8)
        (1, 128, 4, 4)
        (1, 256, 2, 2)
        (1, 512, 1, 1)
    """

    arch_settings = {
        18: (BasicBlock, (2, 2, 2, 2)),
        34: (BasicBlock, (3, 4, 6, 3)),
        50: (Bottleneck, (3, 4, 6, 3)),
        101: (Bottleneck, (3, 4, 23, 3)),
        152: (Bottleneck, (3, 8, 36, 3))
    }

    def __init__(self,
                 depth,
                 in_channels=3,
                 stem_channels=64,
                 base_channels=64,
                 expansion=None,
                 num_stages=4,
                 strides=((1,1), (4,1), (4,1), (4,1) ),
                 dilations=(1, 1, 1, 1),
                 out_indices=(3, ),
                 style='pytorch',
                 avg_down=False,
                 frozen_stages=-1,
                 norm_cfg=dict(type='BN1d', requires_grad=True),
                 norm_eval=False,
                 with_cp=False,
                 nousestride =True,
                 zero_init_residual=True,
                 init_cfg=[
                     dict(type='Kaiming', layer=['Conv2d','Conv1d']),
                     dict(
                         type='Constant',
                         val=1,
                         layer=['_BatchNorm', 'GroupNorm'])
                 ],
                 sphert_cfg =dict(max_res=6,dggs_type='ISEA4D' ,file_dir = './data/sphere/table_Save',regen=False,useAperture=0),#regen是否重新生成
                 drop_path_rate=0.0,
                 act_cfg =dict(type='SiLU', inplace=False)):
        super(sphereResNetHex_1, self).__init__(init_cfg)
 
        self.conv_tables = []
        self.upsample_tables = []
        self.pooling_tables = []
        self.dggs_type = sphert_cfg['dggs_type']
        self.max_res = sphert_cfg['max_res']
        self.current_level = sphert_cfg['max_res']
        self.useAperture =sphert_cfg['useAperture']

        self.sphere_init(sphert_cfg)
        self.act_cfg =act_cfg
        self.nousestride=nousestride
        if depth not in self.arch_settings:
            raise KeyError(f'invalid depth {depth} for resnet')
        self.depth = depth
        self.stem_channels = stem_channels
        self.base_channels = base_channels
        self.num_stages = num_stages
        assert num_stages >= 1 and num_stages <= 4
        self.strides = strides
        self.dilations = dilations
        assert len(strides) == len(dilations) == num_stages
        self.out_indices = out_indices
        assert max(out_indices) < num_stages
        self.style = style
        self.avg_down = avg_down
        self.frozen_stages = frozen_stages
        self.norm_cfg = norm_cfg
        self.with_cp = with_cp
        self.norm_eval = norm_eval
        self.zero_init_residual = zero_init_residual  
        self.block, stage_blocks = self.arch_settings[depth]  
        self.stage_blocks = stage_blocks[:num_stages]  
        self.expansion = get_expansion(self.block, expansion)
        self._make_stem_layer(in_channels, stem_channels)

        self.res_layers = []
        _in_channels = stem_channels
        _out_channels = base_channels * self.expansion
        for i, num_blocks in enumerate(self.stage_blocks): 
            stride = strides[i]
            dilation = dilations[i]
            res_layer = self.make_res_layer(
                block=self.block,
                num_blocks=num_blocks,
                in_channels=_in_channels,
                out_channels=_out_channels,
                kconv=self.k_conv,
                kpool =self.k_pool,
                expansion=self.expansion,
                stride=stride,
                dilation=dilation,
                style=self.style,
                avg_down=self.avg_down,
                with_cp=with_cp,
                nousestride=self.nousestride,
                norm_cfg=norm_cfg,
                drop_path_rate=drop_path_rate,
                act_cfg=act_cfg)
            _in_channels = _out_channels
            _out_channels *= 2
            layer_name = f'layer{i + 1}'
            # print(f'{layer_name}',res_layer)
            self.add_module(layer_name, res_layer)
            self.res_layers.append(layer_name)

        self._freeze_stages()

        self.feat_dim = res_layer[-1].out_channels
    def make_res_layer(self, **kwargs):
        return ResLayer(**kwargs)
    def reset_currentlevel(self ):
         self.current_level=self.max_res
    def sphere_init(self ,sphert_cfg):
      file_path = os.path.join(sphert_cfg['file_dir'],f'{self.dggs_type}_{self.max_res}_table.pickle')
      save_table_path = os.path.abspath(sphert_cfg['file_dir'])
      if (not os.path.isfile(file_path)) or sphert_cfg['regen']:
 
         for res in range(0, self.max_res+1): 
            if res==0: 
               pooling_table = np.array(0)
               conv_table =  np.array(0)
               upsample_table= np.array(0)
            else:
               conv_table = make_adjacency_table(dggs_type=self.dggs_type,resolution = res,save_dir=save_table_path)
               pooling_table = make_pooling_table(dggs_type = self.dggs_type,resolution = res,save_dir=save_table_path,useAperture= self.useAperture)
               if res==self.max_res:
                  upsample_table = np.array(0)  
               else:
                  upsample_table = make_deconv_table(dggs_type = self.dggs_type,resolution = res,save_dir=save_table_path )
            self.conv_tables.append(conv_table)
            self.upsample_tables.append(upsample_table)
            self.pooling_tables.append(pooling_table)
         print(f'sphereResNet : saving  {file_path}')
         self.save2pickle(self.conv_tables,self.upsample_tables,self.pooling_tables,file_path=file_path)
         print(f'sphereResNet : saved')
      else :
         print(f'sphereResNet : {file_path} has exist')
         data =self.load_pickle(file_path=file_path)
         self.conv_tables,self.upsample_tables,self.pooling_tables = data['conv'],data['upsample'],data['pool']
 

      self.k_pool = self.pooling_tables[self.max_res].shape[1] 
      self.k_conv = self.conv_tables[self.max_res].shape[1] 
      self.pool_ks = (1,self.k_pool)
    @property
    def norm1(self):
        return getattr(self, self.norm1_name)

    def save2pickle(self, conv_tables, upsample_tables, pooling_tables, file_path):

        dict_data = {'conv': conv_tables, 'pool': pooling_tables, 'upsample': upsample_tables}
 
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'wb') as f:
            pickle.dump(dict_data, f)

    def load_pickle(self, file_path):
        with open(file_path, 'rb') as f:
            data = pickle.load(f)  # 读取存储的pickle文件
        return data
    def _make_stem_layer(self, in_channels, stem_channels):
 
        self.stem1= ConvModule(
                    self.k_conv,
                    in_channels,
                    stem_channels // 2,
                    k_pool =self.k_pool,
                    stride= (1,1),
                    norm_cfg=self.norm_cfg,
                    act_cfg=self.act_cfg,
                    inplace=True,
                    nousestride=self.nousestride)
        self.stem = sphere_conv_Sequential(  
                ConvModule(
                    self.k_conv,
                    stem_channels // 2,
                    stem_channels // 2,
                    k_pool= None,
                    act_cfg=self.act_cfg,
                    norm_cfg=self.norm_cfg,
                    inplace=True,
                    nousestride=self.nousestride),
                ConvModule(
                    self.k_conv,
                    stem_channels // 2,
                    stem_channels,
                    k_pool= None,
                    act_cfg=self.act_cfg,
                    norm_cfg=self.norm_cfg,
                    inplace=True,
                    nousestride=self.nousestride))
 
        self.maxpool =create_maxpool(k_pool=self.k_pool)
    def _freeze_stages(self):
        if self.frozen_stages >= 0:
            if self.deep_stem:
                self.stem.eval()
                for param in self.stem.parameters():
                    param.requires_grad = False
            else:
                self.norm1.eval()
                for m in [self.conv1, self.norm1]:
                    for param in m.parameters():
                        param.requires_grad = False

        for i in range(1, self.frozen_stages + 1):
            m = getattr(self, f'layer{i}')
            m.eval()
            for param in m.parameters():
                param.requires_grad = False

    def init_weights(self):
        super(sphereResNetHex_1, self).init_weights()
        if (isinstance(self.init_cfg, dict)
                and self.init_cfg['type'] == 'Pretrained'):
 
            return
        if self.zero_init_residual:
            for m in self.modules():
                if isinstance(m, Bottleneck):
                    constant_init(m.norm3, 0)
                elif isinstance(m, BasicBlock):
                    constant_init(m.norm2, 0)
    def printcurrentlevel(self,x ):
      print('current_level',self.current_level)
      print('print x.shape',x.shape)

    def forward(self, x):
 
        x =self.stem1(x,self.conv_tables[self.current_level],self.pooling_tables[self.current_level])
        self.current_level = self.current_level
        x = self.stem(x,self.conv_tables[self.current_level] ) 
        x = self.maxpool(x,self.pooling_tables[self.current_level])
        self.current_level = self.current_level-1
 
        outs = []
        for i, layer_name in enumerate(self.res_layers):
 
            conv_tabels=[self.conv_tables[self.current_level],self.conv_tables[self.current_level-1]]
 
            pooling_tabels=self.pooling_tables[self.current_level]
            res_layer = getattr(self, layer_name)
 
            x = res_layer(x,conv_tabels,pooling_tabels)
            if res_layer.stride[0]!=1: 
                self.current_level = self.current_level-1
            if i in self.out_indices:
                outs.append(x)
        self.reset_currentlevel() 
        return tuple(outs)

    def train(self, mode=True):
        super(sphereResNetHex_1, self).train(mode)
        self._freeze_stages()
        if mode and self.norm_eval:
            for m in self.modules():
                # trick: eval have effect on BatchNorm only
                if isinstance(m, _BatchNorm):
                    m.eval()


